<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><span class="fa fa-user-plus"></span> About</h3>
                </div>
                <div class="panel-body">
                    <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <p align="center"><img src="img/tutwuri.jpg"></img></p>
                            <label class="col-sm-12 control-label"><center><strong>SISTEM INFORMASI <br> SMP NEGERI 7 TANJUNGBALAI</strong></center></label>
                        </thead>
                        <tbody>
                          <div class="col-sm-2" align="center">

                          </div>
                          <div class="col-sm-8" align="center">
                            <br>
                            Sistem Informasi SMP Negeri 7 Tanjungbalai merupakan sebuah sistem informasi yang dirancang untuk membantu
                            setiap pegawai atau orang lain mendapatkan data resmi dari SMP Negeri 7 Tanjungbalai, selain itu bertujuan untuk menjabarkan tentang perancangan dan
							analisis sistem informasi sekolah berbasis web di. Aplikasi dirancang untuk menghasilkan sistem informasi mengenai profil sekolah dan pengelolaan data siswa. 
							Analisis dilakukan untuk menjamin aplikasi layak dipakai oleh pengguna akhir.
                            <br><br><br>
                          </div>
                          <div class="col-sm-2" align="center">
                          </div>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
