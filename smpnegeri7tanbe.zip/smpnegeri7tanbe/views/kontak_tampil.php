<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><span class="fa fa-user-plus"></span> Kontak</h3>
                </div>
                <div class="panel-body">
                    <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <label class="col-sm-12 control-label"><center><strong></center>SMP NEGERI 7 TANJUNGBALAI</strong></label>
                            <p align="center">
                              Jalan D.I Panjaitan, Kelurahan. Pasar Baru, Kecamatan. Sei Tualang Raso<br>
                              Kota Tanjungbalai, Sumatera Utara, Kode Pos : 21341
                            </p>
                        </thead>
                        <tbody>
                          <div class="col-sm-2" align="center">

                          </div>
                          <div class="col-sm-8" align="center">
                            <br>
                            Telp. 085372433018<br>
                            Email : smnegeri7@gmail.com<br>
                            Fax : - <br>
                            Website : smpnegeri7tanbe.epizy.com<br>
                            <br>
                          </div>
                          <div class="col-sm-2" align="center">
                          </div>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
