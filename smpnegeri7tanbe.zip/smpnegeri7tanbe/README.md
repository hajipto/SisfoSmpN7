# native-php-sistem-informasi-arsip-pengadilan
Sistem Informasi Arsip Pengadilan Menggunakan PHP Murni. <br>
Dapat dikembangan menggunakan Framework Yang disukai.

Fitur :
- Arsip Perkara 
- Riwayat Peminjaman Arsip
- Laporan Arsip Perkara
- Laporan Peminjaman
- Cetak Laporan 

Penampakan Sistem :

![Tampilan Home](https://raw.githubusercontent.com/developerkampoeng/native-php-sistem-informasi-arsip-pengadilan/master/Screenshoot/Sc01.png)

<br>

![Riwayat Peminjaman Arsip](https://raw.githubusercontent.com/developerkampoeng/native-php-sistem-informasi-arsip-pengadilan/master/Screenshoot/Sc02.png)

<br>

![Peminjaman Arsip](https://raw.githubusercontent.com/developerkampoeng/native-php-sistem-informasi-arsip-pengadilan/master/Screenshoot/Sc03.png)
