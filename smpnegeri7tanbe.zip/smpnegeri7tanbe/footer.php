<div class="container">
    <div class="row">
        <div class="col-xs-12">
            Copyright &COPY; <?= date('Y')?> Anak Kampus STMIK Royal Kisaran 
            <a href="#">Dokumentasi</a>
            <a href="#">Peta Situs</a>
            <a href="#">Support</a>
        </div>
    </div>
</div>
