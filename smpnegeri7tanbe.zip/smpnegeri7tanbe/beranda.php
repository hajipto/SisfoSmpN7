<div class="container">
    <div class="row">
        <div class ="col-xs-12">

            <div class="alert alert-info">
                <strong>Selamat Datang di Sistem Informasi SMP Negeri 7 Tanjungbalai</strong>
            </div>
        </div>
    </div>
    <div class="row">
        <!--colomn kedua-->
        <div class="col-sm-12 col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">SMP Negeri 7 Tanjungbalai</h3>
                </div>
                <div class="panel-body">
                     <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                       <thead>
                          <p align="center"><img src="img/tutwuri.jpg"></img></p>
                          <p class="label-title" align="center"><strong>SMP NEGERI 7 TANJUNGBALAI</strong></p>
                          <p class="col-sm-12 col-xs-12" align="center">
                            Selamat datang di halaman administrator Sistem Informasi SMP Negeri 7 Tanjungbalai.<br>
                            Melalui halaman ini dapat dilakukan pengelolaan data arsip, pengelolaan data arsip siswa dan guru, <br>
                            dan juga pengelolaan laporan arsip lainnya yang berkaitan dengan SMP Negeri 7 Tanjungbalai.<br><br>
                            Akses menu Master Data pada bagian atas sistem untuk pengelolaan data arsip dan data arsip siswa dan guru.<br>
                            Untuk mengelola laporan, dapat dilakukan dengan mengakses menu report pada bagian atas sistem.<br>
                            Akses menu User untuk mengelola informasi tentang user yang login.<br><br><br>

                          </p>

                         </thead


                    </table>
                </div>
                </div>
            </div>
        </div>
        <!--akhir colomn kedua-->
		<center>
        <div class="col-sm-12 col-xs-7">
            <!--Jika terjadi login error tampilkan pesan ini-->
            <?php if(isset($_GET['error']) ) {?>
            <div class="alert alert-danger">Maaf! Login Gagal, Coba Lagi..</div>
            <?php }?>

            <?php if (isset($_SESSION['username'])) { ?>
            <div class="alert alert-info">
                <strong>Selamat Datang <?=$_SESSION['nama']?></strong>
            </div>
            <?php
           } else { ?>
			<center>
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Masuk Ke Sistem</h3>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" action="proses_login.php" method="post">
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="text" name="user" class="form-control input-sm"
                                   placeholder="Username" required="" autocomplete="off"/>
                            </div>

                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="password" name="pwd" class="form-control input-sm"
                                   placeholder="Password" required="" autocomplete="off"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <button type="submit" name="login" value="login"
                                        class="btn btn-success btn-block"><span class="fa fa-unlock-alt"></span>
                                    Masuk Sistem
                                </button>
                            </div>
							
                    </form>
                </div>
            </div>

        </div>
            <?php } ?>
    </div>
</div>
</center>