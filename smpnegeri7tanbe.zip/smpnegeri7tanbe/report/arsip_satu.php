<!DOCTYPE html>
<html>
    <head>
        <title>Cetak Data Arsip</title>
        <link href="../Assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    </head>  
    <body onload="print()">
        <!--Menampilkan data detail arsip-->
        <?php
        include '../config/koneksi.php';
        $sql = "SELECT * FROM arsip WHERE id='" . $_GET ['id'] . "'";
        //proses query ke database
        $query = mysqli_query($koneksi, $sql) or die("SQL Detail error");
        //Merubaha data hasil query kedalam bentuk array
        $data = mysqli_fetch_array($query);
        ?>   

        <div class="container">
            <div class='row'>
                <div class="col-sm-12">
                    <!--dalam tabel--->
                    <div class="text-center">
                        <h2>Sistem Informasi SMP Negeri 7 Tanjungbalai </h2>
                        <h4>Jalan D.I Panjaitan, Kelurahan. Pasar Baru, Kecamatan. Sei Tualang Raso <br> Kota Tanjungbalai, Sumatera Utara, 21341</h4>
                        <hr>
                        <h3>DATA ARSIP</h3>
                        <table class="table table-bordered table-striped table-hover"> 
                            <tbody>
								<tr>
                                    <td>NIP</td> <td><?= $data['no_perkara'] ?></td>
                                </tr>
                                <tr>
                                    <td width="200">Mapel Yang Diampu</td> <td><?= $data['ruang_arsip'] ?></td>
                                </tr>
                                <tr>
                                    <td>Nomor (Kode Surat)</td> <td><strong><?= $data['no_rak'] ?> - <?= $data['no_laci'] ?> - <?= $data['no_boks'] ?></strong></td>
                                </tr>
                                <tr>
                                    <td>Nama Guru</td> <td><?= $data['para_pihak'] ?></td>
                                </tr>
								<tr>
                                    <td>TMT Kerja</td> <td><?= $data['tgl_masuk'] ?></td>
                                </tr>
								<tr>
                                    <td>Pengumpul Berkas</td> <td><?= $data['pemberi'] ?></td>
                                </tr>
								<tr>
                                    <td>Penerima Berkas</td> <td><?= $data['penerima'] ?></td>
                                </tr>
                            </tbody>
                            <tfoot> 
                                <tr>
                                    <td colspan="2" class="text-right">
                                        Tanjungbalai  <?= date("d-m-Y") ?>
                                        <br><br><br><br>
                                        <u>Sri Gunawan Tarigan, S. Pd<strong></u><br>
                                        NIP.19780301 200604 1 008
									</td>
								</tr>
							</tfoot> 
                        </table>
                    </div>
                </div>
            </div>
    </body>
</html>